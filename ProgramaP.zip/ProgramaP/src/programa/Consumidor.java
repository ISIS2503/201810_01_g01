package programa;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class Consumidor implements MqttCallback {

MqttClient client;

public Consumidor() {
}

public static void main(String[] args) 
{
    new Consumidor().correr();
}

public void correr() 
{
    try 
    {
        client = new MqttClient("tcp://172.24.42.95:8083", MqttClient.generateClientId());
        client.setCallback(this);
        client.connect();
        client.subscribe("alerta/unidadResidencial/residencia");
    } 
    catch (MqttException e) {
        e.printStackTrace();
    }
}

@Override
public void connectionLost(Throwable cause) 
{
	System.out.println("Connection lost"); 
}

@Override
public void messageArrived(String topic, MqttMessage message)
		throws Exception 
{
	String msg = message.toString().split(":")[1];
	msg = msg.substring(1, msg.length()-2);
	String m[] = msg.split("\\\\");
	
	if(m[0].equals("0"))
	{
		m[0] = "Apertura sospechosa";
	}
	else if(m[0].equals("1"))
	{
		m[0] = "Apertura no permitida";
	}
	else
	{
		m[0] = "Puerta abierta";
	}
	System.out.println("Alerta: "+m[0]+" - Unidad residencial: "+m[1]+" - Residencia: "+m[2])   ;
}

@Override
public void deliveryComplete(IMqttDeliveryToken token) 
{
    // TODO Auto-generated method stub

}

}