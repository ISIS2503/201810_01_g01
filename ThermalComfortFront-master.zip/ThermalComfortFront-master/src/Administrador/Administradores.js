import React, { Component } from 'react';
import { Table, Button, FormGroup, ControlLabel, FormControl, Glyphicon } from 'react-bootstrap';
import { API_URL } from './../constants';
import Administrador from './Administrador';
import axios from 'axios';

class Administradores extends Component {
  componentWillMount() {
    this.setState({ 
      administradores: [],
      message: '',
      nombre: '',
      unidadResidencial: '',
      alarmas: ''
    });
  }
  componentDidMount() {
    this.getAdministradores();
  }
  handleNombreChange(event) {
    this.setState({ nombre: event.target.value });
  }
  handleUnidadResidencialChange(event) {
    this.setState({ unidadResidencial: event.target.value });
  }
  addAdministrador(event) {
    event.preventDefault();
    const { getIdToken } = this.props.auth;
    const headers = { Authorization: `Bearer ${getIdToken()}`};
    const floor = { nombre: this.state.nombre, unidadResidencial: this.state.unidadResidencial, alarmas: this.state.alarmas };
    axios.post(`${API_URL}/administrador`, floor, { credentials: true, headers: headers })
    .then(response => this.getAdministradores())
    .catch(error => this.setState({ message: error.message }));
  }
  getAdministradores() {
    const { getIdToken } = this.props.auth;
    const headers = { Authorization: `Bearer ${getIdToken()}`};
    axios.get(`${API_URL}/administrador`, { credentials: true, headers: headers })
    .then(response => this.setState({ administradores: response.data }))
    .catch(error => this.setState({ message: error.message }));
  }
  render() {
    const { isAuthenticated } = this.props.auth;
    return (
      <div className="container">
      <h1>Administradores</h1>
      <h2>Agregar un administrador</h2>
      <form onSubmit={(event) => this.addAdministrador(event)}>
        <FormGroup controlId="formInlineName">
          <ControlLabel>Nombre</ControlLabel>
          {' '}
          <FormControl type="text" placeholder="Name" onChange={(event) => this.handleNameChange(event)} />
        </FormGroup>
        {' '}
        <FormGroup controlId="formInlineCode">
          <ControlLabel>Unidad Residencial</ControlLabel>
          {' '}
          <FormControl type="text" placeholder="Code" onChange={(event) => this.handleCodeChange(event)} />
        </FormGroup>
        {' '}
        <Button bsStyle="success" type="submit">
          <Glyphicon glyph="plus" /> Agregar
        </Button>
      </form>
      <br />
      <Table striped bordered condensed hover className="center">
        <thead>
          <tr>
            <th>#</th>
            <th>ID</th>
            <th>Nombre</th>
            <th>Unidad Residencial</th>
            <th>Alarmas</th>
            <th>Eliminar</th>
            <th>Editar</th>
          </tr>
        </thead>
        <tbody>
          {this.state.administradores.map((administrador, index) => {
          return (
            <Administrador
              key={index}
              number={index + 1}
              id={administrador.id}
              nombre={administrador.nombre}
              unidadResidencial={administrador.unidadResidencial}
              auth={this.props.auth}
              getAdministradores={() => this.getAdministradores()}
            />
          );
        })}
        </tbody>
      </Table>
      <h2>{this.state.message}</h2>
      </div>
      );
  }
}

export default Administradores;


