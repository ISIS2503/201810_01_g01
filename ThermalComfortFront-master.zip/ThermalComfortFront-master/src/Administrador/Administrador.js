import React, { Component } from 'react';
import { Button, Glyphicon, Modal, FormControl, FormGroup, ControlLabel } from 'react-bootstrap';
import { API_URL } from './../constants';
import axios from 'axios';

class Administrador extends Component {
	componentWillMount() {
	    this.setState({ 
	      showModal: false,
	      nombre: '',
	      unidadResidencial: '',
              alarmas: ''
	    });
	 }
	handleNombreChange(event) {
    	this.setState({ nombre: event.target.value });
  	}
  	handleUnidadResidencialChange(event) {
    	this.setState({ unidadResidencial: event.target.value });
  	}
	deleteAdministrador() {
		const { getIdToken } = this.props.auth;
	    const headers = { Authorization: `Bearer ${getIdToken()}`};
	    axios.delete(`${API_URL}/administrador/${this.props.id}`, { credentials: true, headers: headers })
		    .then(response => { 
		    	console.log("Deleted successfully");
		    	this.props.getAdministradores();
		    });
	}
	updateAdministrador() {
		const { getIdToken } = this.props.auth;
		const floor = { id: this.props.id, nombre: this.state.name, unidadResidencial: this.state.code };
	    const headers = { Authorization: `Bearer ${getIdToken()}`};
	    axios.put(`${API_URL}/administrador`, floor, { credentials: true, headers: headers })
		    .then(response => { 
		    	console.log("Updated successfully");
		    	this.close();
		    	this.props.getAdministradores();
		    });
	}
	close() {
	    this.setState({ showModal: false });
	}

	open() {
	    this.setState({ showModal: true });
	}
	render() {
		return (
			<tr>
				<td>{this.props.number}</td>
				<td>{this.props.id}</td>
				<td>{this.props.nombre}</td>
				<td>{this.props.unidadResidencial}</td>
                                <td>{this.props.alarmas}</td>
				<td>
					<Button
                    bsStyle="danger"
                    className="btn-margin"
                    onClick={() => this.deleteAdministrador()}>
                    	<Glyphicon glyph="remove" /> Eliminar
                	</Button>
                </td>
               	<td>
					<Button
                    bsStyle="info"
                    className="btn-margin"
                    onClick={() => this.open()}>
                    	<Glyphicon glyph="edit" /> Editar
                	</Button>
                	<Modal show={this.state.showModal} onHide={() => this.close()}>
			          <Modal.Header closeButton>
			            <Modal.Title>Editar administrador</Modal.Title>
			          </Modal.Header>
			          <Modal.Body>
			            <form>
					        <FormGroup controlId="formInlineName">
					          <ControlLabel>Nombre</ControlLabel>
					          {' '}
					          <FormControl type="text" placeholder={this.props.nombre} onChange={(event) => this.handleNombreChange(event)} />
					        </FormGroup>
					        {' '}
					        <FormGroup controlId="formInlineCode">
					          <ControlLabel>Unidad Residencial</ControlLabel>
					          {' '}
					          <FormControl type="text" placeholder={this.props.code} onChange={(event) => this.handleUnidadResidencialChange(event)} />
					        </FormGroup>
					     </form>
			          </Modal.Body>
			          <Modal.Footer>
			          	<Button 
			          		bsStyle="info"
		                    className="btn-margin"
		                    onClick={(event) => this.updateAdministrador(event)}>
		                    <Glyphicon glyph="edit" /> Guardar
                    	</Button>
			            <Button onClick={() => this.close()}>Cerrar</Button>
			          </Modal.Footer>
			        </Modal>
                </td>
			</tr>

		);
	}
}
export default Administrador;


