export const AUTH_CONFIG = {
  domain: 'isis2503-afleon.auth0.com',
  clientId: 'wpp9LubOdQacRZfZWMyW-KfSbs_iB7X8',
  callbackUrl: 'http://localhost:3000/callback',
  apiUrl: 'uniandes.edu.co/thermalcomfort'
}
